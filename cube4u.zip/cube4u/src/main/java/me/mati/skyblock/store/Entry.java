package me.mati.skyblock.store;

public interface Entry {
    void insert();

    void update(boolean p0);

    void delete();
}
